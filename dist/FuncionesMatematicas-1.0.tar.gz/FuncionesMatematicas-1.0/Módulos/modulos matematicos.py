from Módulos.Funciones_Matematicas.Funciones import *

sumar(8,2)
restar(3,4)
multiplicar(56,23)